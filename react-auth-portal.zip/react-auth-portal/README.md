# Auth Portal (React, Frontend-only)

A clean **login/register portal** built with **React + Vite**.

✅ No backend (demo auth uses `localStorage`)  
✅ Protected route (`/dashboard`)  
✅ Responsive, modern CSS styling  

## Run locally

```bash
npm install
npm run dev
```

Open: `http://localhost:5173`

## Build for production

```bash
npm install
npm run build
```

Vite outputs static files into `dist/`.

## Deploy on EC2 (recommended: Nginx)

1. Build the app on the EC2 instance:

```bash
npm install
npm run build
```

2. Copy the build output to Nginx web root:

```bash
sudo rm -rf /usr/share/nginx/html/*
sudo cp -r dist/* /usr/share/nginx/html/
```

3. Start Nginx:

```bash
sudo systemctl enable nginx
sudo systemctl restart nginx
```

Now visit `http://<EC2_PUBLIC_IP>/`

> Security note: this app is for UI/demo only. Storing users in localStorage is not secure.

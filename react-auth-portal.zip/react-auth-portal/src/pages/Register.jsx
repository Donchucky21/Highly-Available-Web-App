import React, { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import AuthShell from '../components/AuthShell.jsx'
import Field from '../components/Field.jsx'
import Toast from '../components/Toast.jsx'
import { registerUser } from '../lib/auth.js'

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())
}

function passwordScore(pw) {
  let score = 0
  if (!pw) return 0
  if (pw.length >= 8) score++
  if (pw.length >= 12) score++
  if (/[A-Z]/.test(pw)) score++
  if (/[0-9]/.test(pw)) score++
  if (/[^A-Za-z0-9]/.test(pw)) score++
  return Math.min(score, 5)
}

const scoreText = ['Too weak', 'Weak', 'Okay', 'Good', 'Strong', 'Very strong']

export default function Register() {
  const navigate = useNavigate()

  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)

  const score = useMemo(() => passwordScore(password), [password])

  const [toast, setToast] = useState({ kind: 'info', message: '' })
  const [errors, setErrors] = useState({})

  async function onSubmit(e) {
    e.preventDefault()
    const nextErrors = {}

    if (!fullName.trim()) nextErrors.fullName = 'Full name is required.'

    if (!email.trim()) nextErrors.email = 'Email is required.'
    else if (!isValidEmail(email)) nextErrors.email = 'Enter a valid email address.'

    if (!password) nextErrors.password = 'Password is required.'
    else if (password.length < 8) nextErrors.password = 'Use at least 8 characters.'

    if (confirm !== password) nextErrors.confirm = 'Passwords do not match.'

    setErrors(nextErrors)
    if (Object.keys(nextErrors).length) return

    try {
      setBusy(true)
      await registerUser({ fullName, email, password })
      setToast({ kind: 'success', message: 'Account created! Redirecting…' })
      setTimeout(() => navigate('/dashboard'), 600)
    } catch (err) {
      setToast({ kind: 'error', message: err?.message || 'Registration failed.' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthShell hint="No backend needed: this is a UI prototype (users saved in localStorage).">
      <div className="card">
        <div className="cardHeader">
          <h1 className="h1">Create account</h1>
          <p className="muted">Register to access the dashboard.</p>
        </div>

        <form className="form" onSubmit={onSubmit}>
          <Field
            label="Full name"
            value={fullName}
            onChange={e => setFullName(e.target.value)}
            placeholder="Jane Doe"
            autoComplete="name"
            name="fullName"
            error={errors.fullName}
            required
          />

          <Field
            label="Email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            name="email"
            error={errors.email}
            required
          />

          <Field
            label="Password"
            type={show ? 'text' : 'password'}
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Create a password"
            autoComplete="new-password"
            name="password"
            error={errors.password}
            required
            right={
              <button
                type="button"
                className="ghostBtn"
                onClick={() => setShow(s => !s)}
                aria-label={show ? 'Hide password' : 'Show password'}
              >
                {show ? 'Hide' : 'Show'}
              </button>
            }
          />

          <div className="meter" aria-hidden="true">
            <div className="meterBar" style={{ width: `${(score / 5) * 100}%` }} />
          </div>
          <div className="meterText">
            Strength: <span className="chip">{scoreText[score]}</span>
          </div>

          <Field
            label="Confirm password"
            type={show ? 'text' : 'password'}
            value={confirm}
            onChange={e => setConfirm(e.target.value)}
            placeholder="Re-enter password"
            autoComplete="new-password"
            name="confirm"
            error={errors.confirm}
            required
          />

          <label className="check">
            <input type="checkbox" required />
            <span>
              I agree to the <span className="fakeLink">Terms</span> and <span className="fakeLink">Privacy Policy</span>
            </span>
          </label>

          <button className="primaryBtn" type="submit" disabled={busy}>
            {busy ? 'Creating…' : 'Create account'}
          </button>

          <div className="foot">
            <span className="muted">Already have an account?</span> <Link to="/login">Sign in</Link>
          </div>
        </form>

        <Toast
          kind={toast.kind}
          message={toast.message}
          onClose={() => setToast(t => ({ ...t, message: '' }))}
        />
      </div>
    </AuthShell>
  )
}

import React, { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import AuthShell from '../components/AuthShell.jsx'
import Field from '../components/Field.jsx'
import Toast from '../components/Toast.jsx'
import { loginUser, getCurrentUser } from '../lib/auth.js'

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())
}

export default function Login() {
  const navigate = useNavigate()

  const existing = useMemo(() => getCurrentUser(), [])
  const [email, setEmail] = useState(existing?.email ?? '')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)

  const [toast, setToast] = useState({ kind: 'info', message: '' })
  const [errors, setErrors] = useState({})

  async function onSubmit(e) {
    e.preventDefault()
    const nextErrors = {}

    if (!email.trim()) nextErrors.email = 'Email is required.'
    else if (!isValidEmail(email)) nextErrors.email = 'Enter a valid email address.'

    if (!password) nextErrors.password = 'Password is required.'

    setErrors(nextErrors)
    if (Object.keys(nextErrors).length) return

    try {
      setBusy(true)
      await loginUser({ email, password })
      setToast({ kind: 'success', message: 'Welcome back! Redirecting…' })
      setTimeout(() => navigate('/dashboard'), 600)
    } catch (err) {
      setToast({ kind: 'error', message: err?.message || 'Login failed.' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <AuthShell hint="Demo note: Users are stored locally in your browser (localStorage).">
      <div className="card">
        <div className="cardHeader">
          <h1 className="h1">Sign in</h1>
          <p className="muted">Access your portal dashboard.</p>
        </div>

        <form className="form" onSubmit={onSubmit}>
          <Field
            label="Email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="you@example.com"
            autoComplete="email"
            name="email"
            error={errors.email}
            required
          />

          <Field
            label="Password"
            type={show ? 'text' : 'password'}
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Your password"
            autoComplete="current-password"
            name="password"
            error={errors.password}
            required
            right={
              <button
                type="button"
                className="ghostBtn"
                onClick={() => setShow(s => !s)}
                aria-label={show ? 'Hide password' : 'Show password'}
              >
                {show ? 'Hide' : 'Show'}
              </button>
            }
          />

          <div className="row">
            <label className="check">
              <input type="checkbox" defaultChecked />
              <span>Remember me</span>
            </label>
            <button
              type="button"
              className="linkBtn"
              onClick={() => setToast({ kind: 'info', message: 'No backend here 🙂 Try registering a new account.' })}
            >
              Forgot password?
            </button>
          </div>

          <button className="primaryBtn" type="submit" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in'}
          </button>

          <div className="foot">
            <span className="muted">New here?</span> <Link to="/register">Create an account</Link>
          </div>
        </form>

        <Toast
          kind={toast.kind}
          message={toast.message}
          onClose={() => setToast(t => ({ ...t, message: '' }))}
        />
      </div>
    </AuthShell>
  )
}

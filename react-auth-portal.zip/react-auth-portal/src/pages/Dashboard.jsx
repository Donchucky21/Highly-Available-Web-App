import React, { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Logo from '../components/Logo.jsx'
import Toast from '../components/Toast.jsx'
import { clearAllAuthData, getCurrentUser, getUsers, logout } from '../lib/auth.js'

export default function Dashboard() {
  const navigate = useNavigate()
  const user = useMemo(() => getCurrentUser(), [])
  const users = useMemo(() => getUsers(), [])

  const [toast, setToast] = useState({ kind: 'info', message: '' })

  function onLogout() {
    logout()
    navigate('/login')
  }

  function onClearDemoData() {
    clearAllAuthData()
    setToast({ kind: 'success', message: 'Demo data cleared. Redirecting…' })
    setTimeout(() => navigate('/register'), 650)
  }

  return (
    <div className="dashPage">
      <header className="dashHeader">
        <div className="dashBrand">
          <Logo subtitle="Dashboard" />
        </div>

        <div className="dashActions">
          <button className="secondaryBtn" onClick={() => setToast({ kind: 'info', message: 'This is just a frontend demo 🙂' })}>
            Help
          </button>
          <button className="primaryBtn" onClick={onLogout}>Log out</button>
        </div>
      </header>

      <div className="dashWrap">
        <section className="dashHero">
          <div>
            <div className="pill">Signed in</div>
            <h1 className="h1">Welcome, {user?.fullName || 'friend'} 👋</h1>
            <p className="muted">
              Your session is stored in <span className="chip">localStorage</span>. No backend is used.
            </p>
          </div>

          <div className="heroCard">
            <div className="kv">
              <div className="k">Email</div>
              <div className="v">{user?.email}</div>
            </div>
            <div className="kv">
              <div className="k">Users registered on this browser</div>
              <div className="v">{users.length}</div>
            </div>
            <div className="kv">
              <div className="k">Status</div>
              <div className="v"><span className="status">Active</span></div>
            </div>
          </div>
        </section>

        <section className="dashGrid">
          <div className="panel">
            <h2 className="h2">Registered users (demo)</h2>
            <p className="muted">Stored locally on this device only.</p>

            <div className="table">
              <div className="tHead">
                <div>Name</div>
                <div>Email</div>
              </div>
              {users.slice(0, 8).map(u => (
                <div key={u.id} className="tRow">
                  <div className="tName">{u.fullName}</div>
                  <div className="tEmail">{u.email}</div>
                </div>
              ))}
              {users.length === 0 ? <div className="empty">No users found.</div> : null}
            </div>
          </div>

          <div className="panel">
            <h2 className="h2">What you can do next</h2>
            <ul className="checkList">
              <li>Wire this UI to an API (Node/.NET/Python).</li>
              <li>Swap localStorage for JWT + cookies.</li>
              <li>Add MFA, password reset, and email verification.</li>
            </ul>

            <div className="divider" />

            <h3 className="h3">Demo controls</h3>
            <p className="muted">Handy for resetting during presentations.</p>
            <button className="dangerBtn" onClick={onClearDemoData}>Clear all demo auth data</button>
          </div>
        </section>
      </div>

      <Toast
        kind={toast.kind}
        message={toast.message}
        onClose={() => setToast(t => ({ ...t, message: '' }))}
      />
    </div>
  )
}

import React, { useEffect } from 'react'

export default function Toast({ kind = 'info', message, onClose }) {
  useEffect(() => {
    if (!message) return
    const t = setTimeout(() => onClose?.(), 4500)
    return () => clearTimeout(t)
  }, [message, onClose])

  if (!message) return null

  return (
    <div className={`toast toast-${kind}`} role="status" aria-live="polite">
      <div className="toastDot" aria-hidden="true" />
      <div className="toastText">{message}</div>
      <button className="toastClose" onClick={onClose} aria-label="Close notification">
        ×
      </button>
    </div>
  )
}

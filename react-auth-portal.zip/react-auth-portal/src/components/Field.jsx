import React from 'react'

export default function Field({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  error,
  right,
  autoComplete,
  name,
  inputMode,
  required
}) {
  return (
    <div className="field">
      <label className="label">
        <span>{label}</span>
        <div className={`inputWrap ${error ? 'inputError' : ''}`}>
          <input
            className="input"
            type={type}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            autoComplete={autoComplete}
            name={name}
            inputMode={inputMode}
            required={required}
          />
          {right ? <div className="inputRight">{right}</div> : null}
        </div>
      </label>
      {error ? <div className="fieldError">{error}</div> : null}
    </div>
  )
}

import React from 'react'
import Logo from './Logo.jsx'

export default function AuthShell({ children, hint }) {
  return (
    <div className="authPage">
      <div className="authGrid">
        <aside className="authAside">
          <Logo subtitle="Login • Register • Dashboard" />

          <div className="asideCard">
            <h2 className="asideTitle">A clean, frontend-only portal</h2>
            <p className="asideText">
              This demo app stores users in <span className="chip">localStorage</span>.
              Perfect for UI demos, prototypes, and quick onboarding flows.
            </p>
            <ul className="asideList">
              <li>Responsive layout</li>
              <li>Form validation & feedback</li>
              <li>Simple protected route</li>
            </ul>

            <div className="asideHint">{hint}</div>
          </div>

          <div className="asideFoot">
            <span>Tip:</span> Build it on your EC2 and serve via Nginx.
          </div>
        </aside>

        <main className="authMain">{children}</main>
      </div>
    </div>
  )
}

import React from 'react'

export default function Logo({ subtitle = 'Secure Portal' }) {
  return (
    <div className="logo">
      <div className="logoMark" aria-hidden="true">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <path
            d="M12 2l7 4v6c0 5-3 9-7 10-4-1-7-5-7-10V6l7-4z"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <path
            d="M9.2 12.1l1.9 1.9 3.9-4.1"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      <div>
        <div className="logoTitle">Auth Portal</div>
        <div className="logoSubtitle">{subtitle}</div>
      </div>
    </div>
  )
}
